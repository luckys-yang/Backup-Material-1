//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//+ v01
//+ 2016.11.22  15:05
//+ EVE LEE
//+ www.evelee.cc
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#ifndef __MY1690_H
#define __MY1690_H

extern const unsigned char MY1690_Play[5],MY1690_Stop[5],MY1690_Next[5],MY1690_Last[5];
extern const unsigned char MY1690_Add[5],MY1690_Cut[5],MY1690_FF[5],MY1690_FB[5];

extern void MY1690_Config(void);
extern void MY1690_SendCMD(unsigned char *CMD);
void MY1690_SetEQ(unsigned char Data);
void MY1690_SetVOL(unsigned char Data);
void MY1690_SetLoop(unsigned char Data);
void MY1690_SetDevice(unsigned char Data);
void MY1690_Jump(unsigned char Dir,unsigned char Fil);

#endif
